import * as THREE from 'three';

export class TextureManager {
    constructor() {
        this.currentPaintTexture = null;
        this.TEXTURE_SIZE = 1024;
    }

    loadTexture(file) {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            
            reader.onload = (e) => {
                const img = new Image();
                
                img.onload = () => {
                    // Create a canvas with power-of-two dimensions
                    const canvas = document.createElement('canvas');
                    canvas.width = this.TEXTURE_SIZE;
                    canvas.height = this.TEXTURE_SIZE;
                    
                    const ctx = canvas.getContext('2d');
                    
                    // Draw the image maintaining aspect ratio
                    const scale = Math.min(
                        canvas.width / img.width,
                        canvas.height / img.height
                    );
                    
                    const width = img.width * scale;
                    const height = img.height * scale;
                    const x = (canvas.width - width) / 2;
                    const y = (canvas.height - height) / 2;
                    
                    // Clear canvas and draw the scaled image
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.drawImage(img, x, y, width, height);
                    
                    this.currentPaintTexture = canvas;
                    console.log('Texture loaded and normalized successfully');
                    resolve(canvas);
                };
                
                img.onerror = (error) => {
                    console.error('Failed to load texture image:', error);
                    reject(error);
                };
                
                img.src = e.target.result;
            };
            
            reader.onerror = (error) => {
                console.error('Failed to read texture file:', error);
                reject(error);
            };
            
            reader.readAsDataURL(file);
        });
    }

    createNewCanvasTexture() {
        const canvas = document.createElement('canvas');
        canvas.width = this.TEXTURE_SIZE;
        canvas.height = this.TEXTURE_SIZE;
        
        const context = canvas.getContext('2d');
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        
        const texture = new THREE.CanvasTexture(canvas);
        texture.premultiplyAlpha = false;
        texture.needsUpdate = true;
        return texture;
    }

    initializeMeshTexture(mesh) {
        if (!mesh.material.map) {
            const texture = this.createNewCanvasTexture();
            mesh.material.map = texture;
            mesh.material.transparent = true;
            mesh.material.needsUpdate = true;
        }
        return mesh.material.map;
    }

    clearCurrentTexture() {
        this.currentPaintTexture = null;
    }

    getCurrentTexture() {
        return this.currentPaintTexture;
    }
}