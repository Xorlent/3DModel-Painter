import * as THREE from 'three';

export class PaintManager {
    constructor(sceneManager, textureManager) {
        this.sceneManager = sceneManager;
        this.textureManager = textureManager;
        this.isPainting = false;
        this.raycaster = new THREE.Raycaster();
        this.mouse = new THREE.Vector2();
        this.isMouseDown = false;
        this.lastPaintPosition = null;

        // Bind methods
        this.paint = this.paint.bind(this);
        this.onMouseDown = this.onMouseDown.bind(this);
        this.onMouseMove = this.onMouseMove.bind(this);
        this.onMouseUp = this.onMouseUp.bind(this);

        this.setupEventListeners();
    }

    setupEventListeners() {
        const renderer = this.sceneManager.renderer;
        renderer.domElement.addEventListener('mousedown', this.onMouseDown);
        renderer.domElement.addEventListener('mousemove', this.onMouseMove);
        renderer.domElement.addEventListener('mouseup', this.onMouseUp);
        renderer.domElement.addEventListener('mouseleave', this.onMouseUp);
    }

    togglePaintMode() {
        this.isPainting = !this.isPainting;
        this.sceneManager.controls.enabled = !this.isPainting;
        
        if (this.isPainting && this.sceneManager.currentModel) {
            this.initializePaintMode();
        }
        
        return this.isPainting;
    }

    initializePaintMode() {
        this.sceneManager.currentModel.traverse((child) => {
            if (child.isMesh) {
                this.textureManager.initializeMeshTexture(child);
            }
        });
    }

    onMouseDown(event) {
        this.isMouseDown = true;
        if (this.isPainting) {
            this.lastPaintPosition = null;
            this.paint(event);
        }
    }

    onMouseMove(event) {
        if (this.isPainting && this.isMouseDown) {
            this.paint(event);
        }
    }

    onMouseUp() {
        this.isMouseDown = false;
        this.lastPaintPosition = null;
    }

    paint(event) {
        if (!this.sceneManager.currentModel || !this.isPainting || !this.textureManager.getCurrentTexture()) {
            return;
        }

        const rect = this.sceneManager.renderer.domElement.getBoundingClientRect();
        this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

        this.raycaster.setFromCamera(this.mouse, this.sceneManager.camera);
        const intersects = this.raycaster.intersectObject(this.sceneManager.currentModel, true);

        if (intersects.length > 0) {
            const intersect = intersects[0];
            if (!intersect.uv) return;

            const mesh = intersect.object;
            const texture = this.textureManager.initializeMeshTexture(mesh);
            
            this.paintTextureAtPoint(
                texture,
                intersect.uv,
                parseInt(document.getElementById('brushSize').value),
                parseFloat(document.getElementById('paintOpacity').value) / 100,
                mesh
            );
        }
    }

    paintTextureAtPoint(targetTexture, uv, brushSize, opacity, mesh) {
        const canvas = targetTexture.image;
        const context = canvas.getContext('2d');
        
        const x = Math.floor(uv.x * canvas.width);
        const y = Math.floor((1 - uv.y) * canvas.height);
        
        // Get the current texture pattern
        const currentTexture = this.textureManager.getCurrentTexture();
        if (!currentTexture) return;

        // Save the current canvas state
        context.save();

        // Set up the clipping region for the brush stroke
        context.beginPath();
        context.arc(x, y, brushSize, 0, Math.PI * 2);
        context.closePath();

        // Clip to only affect the brush area
        context.clip();

        // Set global alpha for opacity
        context.globalAlpha = opacity;

        // Draw the texture within the clipped area
        context.drawImage(
            currentTexture,
            x - brushSize, y - brushSize,
            brushSize * 2, brushSize * 2
        );

        // Restore the canvas state
        context.restore();

        // Update the texture
        targetTexture.needsUpdate = true;
    }

    dispose() {
        const renderer = this.sceneManager.renderer;
        renderer.domElement.removeEventListener('mousedown', this.onMouseDown);
        renderer.domElement.removeEventListener('mousemove', this.onMouseMove);
        renderer.domElement.removeEventListener('mouseup', this.onMouseUp);
        renderer.domElement.removeEventListener('mouseleave', this.onMouseUp);
    }
}