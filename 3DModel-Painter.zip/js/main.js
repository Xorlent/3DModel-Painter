import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

let scene, camera, renderer, controls;
let model, selectedFace;
let paintMode = false;
let currentTexture = null;

// Initialize the scene
function init() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // Setup camera and controls
    camera.position.z = 5;
    controls = new OrbitControls(camera, renderer.domElement);
    
    // Add lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    const pointLight = new THREE.PointLight(0xffffff, 1);
    pointLight.position.set(5, 5, 5);
    scene.add(ambientLight, pointLight);

    // Setup event listeners
    setupEventListeners();
    
    animate();
}

function setupEventListeners() {
    // Model loading
    document.getElementById('modelInput').addEventListener('change', handleModelLoad);
    
    // Paint controls
    document.getElementById('paintType').addEventListener('change', handlePaintTypeChange);
    document.getElementById('facePaintMode').addEventListener('click', togglePaintMode);
    document.getElementById('textureInput').addEventListener('change', handleTextureLoad);
    document.getElementById('clearTexture').addEventListener('click', clearTexture);
    
    // Raycasting for face selection
    renderer.domElement.addEventListener('mousemove', highlightFace);
    renderer.domElement.addEventListener('click', paintFace);
    
    // Camera reset
    document.getElementById('resetCamera').addEventListener('click', resetCamera);
    
    // Window resize
    window.addEventListener('resize', onWindowResize);
}

function handlePaintTypeChange(event) {
    const paintType = event.target.value;
    document.getElementById('colorControls').style.display = 
        paintType === 'color' ? 'block' : 'none';
    document.getElementById('textureMapControls').style.display = 
        paintType === 'texture' ? 'block' : 'none';
}

function handleModelLoad(event) {
    const file = event.target.files[0];
    const loader = new GLTFLoader();
    
    loader.load(
        URL.createObjectURL(file),
        function(gltf) {
            if (model) scene.remove(model);
            model = gltf.scene;
            scene.add(model);
            resetCamera();
        }
    );
}

function handleTextureLoad(event) {
    const file = event.target.files[0];
    const reader = new FileReader();
    
    reader.onload = function(e) {
        const img = new Image();
        img.src = e.target.result;
        
        img.onload = function() {
            currentTexture = new THREE.Texture(img);
            currentTexture.needsUpdate = true;
            
            // Update preview
            const preview = document.getElementById('texturePreview');
            preview.innerHTML = '';
            preview.appendChild(img.cloneNode());
        };
    };
    
    reader.readAsDataURL(file);
}

function highlightFace(event) {
    if (!paintMode || !model) return;

    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();
    
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;
    
    raycaster.setFromCamera(mouse, camera);
    const intersects = raycaster.intersectObject(model, true);
    
    // Reset previous highlight
    if (selectedFace) {
        selectedFace.material.emissive.setHex(0x000000);
    }
    
    if (intersects.length > 0) {
        selectedFace = intersects[0].object;
        selectedFace.material.emissive.setHex(0x666666);
    }
}

function paintFace(event) {
    if (!paintMode || !selectedFace) return;
    
    const paintType = document.getElementById('paintType').value;
    const opacity = document.getElementById('paintOpacity').value / 100;
    
    if (paintType === 'color') {
        const color = new THREE.Color(document.getElementById('paintColor').value);
        selectedFace.material = new THREE.MeshStandardMaterial({
            color: color,
            opacity: opacity,
            transparent: opacity < 1
        });
    } else {
        if (!currentTexture) return;
        selectedFace.material = new THREE.MeshStandardMaterial({
            map: currentTexture,
            opacity: opacity,
            transparent: opacity < 1
        });
    }
}

function clearTexture() {
    if (!selectedFace) return;
    selectedFace.material = new THREE.MeshStandardMaterial({
        color: 0xffffff
    });
}

function togglePaintMode() {
    paintMode = !paintMode;
    document.getElementById('facePaintMode').style.background = 
        paintMode ? '#ff4444' : '#4CAF50';
}

function resetCamera() {
    if (!model) return;
    
    const box = new THREE.Box3().setFromObject(model);
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    
    const maxDim = Math.max(size.x, size.y, size.z);
    const fov = camera.fov * (Math.PI / 180);
    const cameraZ = Math.abs(maxDim / Math.tan(fov / 2));
    
    camera.position.set(center.x, center.y, center.z + cameraZ);
    camera.lookAt(center);
    controls.target.copy(center);
    controls.update();
}

function onWindowResize() {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
}

// Start the application
init();