import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export class SceneManager {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
        this.currentModel = null;
        
        this.init();
        this.animate = this.animate.bind(this);
    }

    init() {
        // Scene setup
        this.scene = new THREE.Scene();
        this.scene.background = new THREE.Color(0xcccccc);

        // Camera setup
        this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
        this.camera.position.set(0, 2, 5);
        this.camera.lookAt(0, 0, 0);

        // Renderer setup
        this.renderer = new THREE.WebGLRenderer({ 
            antialias: true,
            preserveDrawingBuffer: true  // Important for texture painting
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(window.devicePixelRatio);
        document.body.appendChild(this.renderer.domElement);

        // Lighting
        this.setupLighting();

        // Controls
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;
        this.controls.screenSpacePanning = false;
        this.controls.minDistance = 1;
        this.controls.maxDistance = 50;
        this.controls.maxPolarAngle = Math.PI / 2;
        this.controls.target.set(0, 0, 0);
        this.controls.update();

        // Event listeners
        window.addEventListener('resize', () => this.onWindowResize(), false);
    }

    setupLighting() {
        // Ambient light
        const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
        this.scene.add(ambientLight);

        // Main directional light
        const mainLight = new THREE.DirectionalLight(0xffffff, 1);
        mainLight.position.set(5, 5, 5);
        this.scene.add(mainLight);

        // Fill light
        const fillLight = new THREE.DirectionalLight(0xffffff, 0.3);
        fillLight.position.set(-5, -5, -5);
        this.scene.add(fillLight);

        // Top light
        const topLight = new THREE.DirectionalLight(0xffffff, 0.2);
        topLight.position.set(0, 5, 0);
        this.scene.add(topLight);
    }

    loadModel(file) {
        console.log('Loading model:', file.name);
        const loader = new GLTFLoader();
        const url = URL.createObjectURL(file);

        return new Promise((resolve, reject) => {
            loader.load(
                url,
                (gltf) => {
                    console.log('Model loaded successfully');
                    
                    if (this.currentModel) {
                        this.scene.remove(this.currentModel);
                    }
                    
                    this.currentModel = gltf.scene;
                    
                    // Process materials
                    this.currentModel.traverse((child) => {
                        if (child.isMesh) {
                            // Create new material if none exists
                            if (!child.material) {
                                child.material = new THREE.MeshStandardMaterial();
                            }
                            // Convert to MeshStandardMaterial if it's not already
                            else if (!(child.material instanceof THREE.MeshStandardMaterial)) {
                                const oldMaterial = child.material;
                                const newMaterial = new THREE.MeshStandardMaterial();
                                
                                // Copy relevant properties
                                if (oldMaterial.map) newMaterial.map = oldMaterial.map;
                                if (oldMaterial.color) newMaterial.color = oldMaterial.color;
                                
                                child.material = newMaterial;
                            }
                            
                            // Set material properties
                            child.material.side = THREE.DoubleSide;
                            child.material.transparent = true;
                            child.material.needsUpdate = true;
                        }
                    });

                    this.scene.add(this.currentModel);
                    this.centerModel();
                    this.resetCamera();
                    
                    resolve(this.currentModel);
                },
                (xhr) => {
                    const percent = (xhr.loaded / xhr.total * 100).toFixed(2);
                    console.log(`Loading progress: ${percent}%`);
                },
                (error) => {
                    console.error('Error loading model:', error);
                    reject(error);
                }
            );
        }).finally(() => {
            URL.revokeObjectURL(url);
        });
    }

    centerModel() {
        if (!this.currentModel) return;

        const box = new THREE.Box3().setFromObject(this.currentModel);
        const center = box.getCenter(new THREE.Vector3());
        const size = box.getSize(new THREE.Vector3());
        
        const maxDim = Math.max(size.x, size.y, size.z);
        const scale = 2 / maxDim;
        
        this.currentModel.scale.setScalar(scale);
        this.currentModel.position.sub(center.multiplyScalar(scale));
        
        this.currentModel.updateMatrixWorld(true);
    }

    resetCamera() {
        this.camera.position.set(0, 2, 5);
        this.camera.lookAt(0, 0, 0);
        this.controls.target.set(0, 0, 0);
        this.controls.update();
    }

    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }

    animate() {
        requestAnimationFrame(this.animate);
        this.controls.update();
        this.renderer.render(this.scene, this.camera);
    }

    dispose() {
        window.removeEventListener('resize', this.onWindowResize);
        
        if (this.currentModel) {
            this.currentModel.traverse((child) => {
                if (child.isMesh) {
                    child.geometry.dispose();
                    if (child.material.map) {
                        child.material.map.dispose();
                    }
                    child.material.dispose();
                }
            });
        }
        
        this.renderer.dispose();
        this.scene.clear();
    }
}